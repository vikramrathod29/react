import React, { Component } from 'react'

export default class Task3rcc extends Component {
  render() {
    return (
      <div>
        <h1>Welcome to react!</h1>
      </div>
    )
  }
}
