import React from 'react'

export default function Task1() {
  return (
    <div>
        <h1>Hello react</h1>
    </div>
  )
}
