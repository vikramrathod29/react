import React from 'react'

export default function Task3({name}) {
  return (
    <div>
        <h3>hello,{name}</h3>
    </div>
  )
}
